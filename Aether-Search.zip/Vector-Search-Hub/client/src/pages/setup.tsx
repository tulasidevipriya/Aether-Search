import { CodeBlock } from "@/components/code-block";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Copy } from "lucide-react";

export default function SetupGuide() {
  return (
    <div className="max-w-3xl mx-auto space-y-12 pb-10">
      <div className="space-y-4">
        <h1 className="text-4xl font-display font-bold">Setup Guide</h1>
        <p className="text-xl text-muted-foreground">
          Follow these instructions to get the project running locally.
        </p>
      </div>

      <div className="space-y-8">
        <section className="space-y-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary text-sm">1</span>
            Prerequisites
          </h2>
          <ul className="grid gap-2 text-muted-foreground ml-10">
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" /> Node.js v18 or higher</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" /> npm or yarn</li>
            <li className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" /> OpenAI API Key (for embeddings)</li>
          </ul>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary text-sm">2</span>
            Installation
          </h2>
          <div className="ml-10 space-y-4">
            <p className="text-muted-foreground">Clone the repository and install dependencies.</p>
            <CodeBlock 
              code={`git clone https://github.com/your-username/endee-vector-search.git
cd endee-vector-search
npm install`} 
              language="bash" 
            />
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
             <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary text-sm">3</span>
            Configuration
          </h2>
          <div className="ml-10 space-y-4">
            <p className="text-muted-foreground">Create a <code className="text-primary bg-primary/10 px-1 rounded">.env</code> file in the root directory.</p>
            <CodeBlock 
              code={`OPENAI_API_KEY=sk-your-api-key-here
ENDEE_DB_PATH=./data/vectors`} 
              language="bash" 
            />
          </div>
        </section>

        <section className="space-y-4">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <span className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary text-sm">4</span>
            Run the Project
          </h2>
          <div className="ml-10 space-y-4">
            <p className="text-muted-foreground">Start the development server.</p>
            <CodeBlock 
              code={`npm run dev`} 
              language="bash" 
            />
            <p className="text-muted-foreground">The application will be available at <code className="text-primary">http://localhost:5000</code></p>
          </div>
        </section>
      </div>
    </div>
  );
}
