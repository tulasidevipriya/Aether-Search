import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Search, Sparkles, Loader2, Database, FileText } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { searchVectors, generateRAGResponse, type Doc } from "@/lib/mock-data";
import { motion, AnimatePresence } from "framer-motion";

export default function SearchDemo() {
  const [query, setQuery] = useState("");
  const [ragAnswer, setRagAnswer] = useState<string | null>(null);

  const searchMutation = useMutation({
    mutationFn: searchVectors,
    onSuccess: (data) => {
      // Trigger RAG generation automatically after search
      ragMutation.mutate({ query, context: data });
    }
  });

  const ragMutation = useMutation({
    mutationFn: ({ query, context }: { query: string, context: Doc[] }) => 
      generateRAGResponse(query, context),
    onSuccess: (data) => setRagAnswer(data)
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setRagAnswer(null);
    searchMutation.mutate(query);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="text-center space-y-4 mb-12">
        <h1 className="text-3xl md:text-5xl font-display font-bold">Semantic Search & RAG</h1>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Experience the power of Endee vector search. Type a query to retrieve relevant documents and generate an AI-augmented response.
        </p>
      </div>

      {/* Search Input */}
      <Card className="border-primary/20 shadow-lg shadow-primary/5 bg-card/80 backdrop-blur">
        <CardContent className="p-2">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input 
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask about Space, AI, Physics..." 
                className="pl-12 h-14 text-lg bg-transparent border-none focus-visible:ring-0 shadow-none"
              />
            </div>
            <Button 
              type="submit" 
              size="lg" 
              className="h-14 px-8 text-lg"
              disabled={searchMutation.isPending}
            >
              {searchMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin mr-2" />
              ) : (
                <Sparkles className="w-5 h-5 mr-2" />
              )}
              Generate
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Results Column */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold flex items-center gap-2">
              <Database className="w-5 h-5 text-primary" />
              Retrieved Context
            </h2>
            {searchMutation.data && (
              <span className="text-sm text-muted-foreground">
                {searchMutation.data.length} documents found in 600ms
              </span>
            )}
          </div>

          <div className="space-y-4 min-h-[300px]">
            {searchMutation.isPending && (
              <div className="flex flex-col gap-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-32 rounded-lg bg-card/50 border border-border/50 animate-pulse" />
                ))}
              </div>
            )}

            {!searchMutation.isPending && !searchMutation.data && (
              <div className="h-64 flex flex-col items-center justify-center text-muted-foreground border border-dashed border-border rounded-lg bg-card/30">
                <Search className="w-12 h-12 mb-4 opacity-20" />
                <p>Enter a query to start searching</p>
              </div>
            )}

            <AnimatePresence mode="popLayout">
              {searchMutation.data?.map((doc, index) => (
                <motion.div
                  key={doc.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="hover:border-primary/50 transition-colors group">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-start">
                        <div className="space-y-1">
                          <CardTitle className="text-base text-primary group-hover:underline decoration-primary/50 underline-offset-4">
                            {doc.title}
                          </CardTitle>
                          <div className="flex gap-2">
                            <Badge variant="outline" className="text-xs font-mono opacity-70">
                              {doc.category}
                            </Badge>
                            <Badge variant="secondary" className="text-xs font-mono">
                              ID: {doc.vector_id}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-2xl font-bold font-mono text-primary">
                            {Math.round((doc.score || 0) * 100)}%
                          </span>
                          <div className="text-xs text-muted-foreground">Match Score</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pb-4">
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {doc.content}
                      </p>
                    </CardContent>
                    <CardFooter className="pt-0 pb-4">
                      <Progress value={(doc.score || 0) * 100} className="h-1 bg-secondary" />
                    </CardFooter>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>

        {/* RAG Answer Column */}
        <div className="space-y-6">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-400" />
            AI Generated Answer
          </h2>
          
          <Card className="h-full min-h-[400px] border-purple-500/20 bg-gradient-to-b from-card to-purple-950/10">
            <CardContent className="p-6">
              {ragMutation.isPending && (
                 <div className="flex flex-col items-center justify-center h-64 text-center space-y-4">
                   <div className="relative w-16 h-16">
                     <div className="absolute inset-0 border-4 border-purple-500/30 rounded-full"></div>
                     <div className="absolute inset-0 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
                   </div>
                   <p className="text-sm text-muted-foreground animate-pulse">
                     Synthesizing answer from retrieved context...
                   </p>
                 </div>
              )}

              {!ragMutation.isPending && !ragAnswer && (
                 <div className="flex flex-col items-center justify-center h-64 text-center space-y-4 opacity-50">
                   <FileText className="w-12 h-12" />
                   <p className="text-sm">Response will appear here</p>
                 </div>
              )}

              {ragAnswer && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="prose prose-invert prose-sm"
                >
                  <p className="text-lg leading-relaxed font-light text-foreground/90">
                    {ragAnswer}
                  </p>
                  
                  <div className="mt-8 pt-4 border-t border-border/50">
                    <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-2">Sources Used</h4>
                    <div className="flex flex-wrap gap-2">
                      {searchMutation.data?.slice(0, 1).map(doc => (
                        <Badge key={doc.id} variant="secondary" className="bg-purple-500/10 text-purple-300 border-purple-500/20 hover:bg-purple-500/20">
                          {doc.title}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
