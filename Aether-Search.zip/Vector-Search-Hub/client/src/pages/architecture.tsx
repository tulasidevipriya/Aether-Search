import { CodeBlock } from "@/components/code-block";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

export default function Architecture() {
  return (
    <div className="max-w-4xl mx-auto space-y-12">
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-primary font-mono text-sm uppercase tracking-wider">
          <div className="w-2 h-2 rounded-full bg-primary" />
          System Design
        </div>
        <h1 className="text-4xl md:text-5xl font-display font-bold">Endee Integration Architecture</h1>
        <p className="text-xl text-muted-foreground leading-relaxed">
          How this project leverages Endee for efficient vector storage and retrieval in a RAG pipeline.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-8">
          <section className="space-y-4">
            <h2 className="text-2xl font-bold font-display">Data Ingestion Pipeline</h2>
            <p className="text-muted-foreground">
              Before we can search, we need to index our knowledge base. The system processes raw text documents, chunks them into manageable segments, and generates vector embeddings.
            </p>
            
            <Card className="bg-card/50 backdrop-blur">
              <CardContent className="p-6">
                 <div className="flex items-center justify-between gap-4 text-sm font-mono text-center">
                    <div className="bg-zinc-900 p-4 rounded border border-zinc-800 w-24">Raw Data</div>
                    <div className="h-px bg-zinc-700 flex-1 relative">
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-zinc-950 px-2 text-xs text-zinc-500">Chunking</div>
                    </div>
                    <div className="bg-zinc-900 p-4 rounded border border-zinc-800 w-24">Text Chunks</div>
                    <div className="h-px bg-zinc-700 flex-1 relative">
                       <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-zinc-950 px-2 text-xs text-zinc-500">Embedding</div>
                    </div>
                    <div className="bg-primary/20 p-4 rounded border border-primary/50 text-primary w-24 font-bold">Endee DB</div>
                 </div>
              </CardContent>
            </Card>

            <CodeBlock 
              code={`import { Endee } from 'endee';
import { OpenAIEmbeddings } from 'langchain/embeddings/openai';

const db = new Endee({ path: './vectors' });
const embedder = new OpenAIEmbeddings();

async function ingest(documents) {
  for (const doc of documents) {
    const vector = await embedder.embedQuery(doc.content);
    await db.add({
      id: doc.id,
      vector: vector,
      metadata: { title: doc.title, category: doc.category }
    });
  }
  console.log('Ingestion complete');
}`} 
              language="typescript" 
            />
          </section>

          <section className="space-y-4">
            <h2 className="text-2xl font-bold font-display">Retrieval & Generation (RAG)</h2>
            <p className="text-muted-foreground">
              When a user asks a question, the system embeds the query, finds the nearest neighbors in Endee, and constructs a prompt for the LLM.
            </p>
            <CodeBlock 
              code={`async function search(query) {
  const queryVector = await embedder.embedQuery(query);
  
  // Perform similarity search
  const results = await db.search(queryVector, { limit: 3 });
  
  // Construct context
  const context = results.map(r => r.metadata.content).join("\\n");
  
  // Generate answer
  const response = await llm.predict(
    \`Answer based on this context: \${context}\\n\\nQuestion: \${query}\`
  );
  
  return response;
}`} 
              language="typescript" 
            />
          </section>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Tech Stack</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2 text-sm text-primary uppercase">Core</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge variant="secondary">React</Badge>
                  <Badge variant="secondary">TypeScript</Badge>
                  <Badge variant="secondary">Node.js</Badge>
                </div>
              </div>
              <div>
                <h4 className="font-semibold mb-2 text-sm text-primary uppercase">AI / Data</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge>Endee DB</Badge>
                  <Badge variant="outline">OpenAI API</Badge>
                  <Badge variant="outline">LangChain</Badge>
                </div>
              </div>
              <Separator />
              <div className="text-sm text-muted-foreground">
                <p>
                  Endee is chosen for its lightweight footprint and ease of local development, eliminating the need for external vector services like Pinecone or Weaviate during the prototyping phase.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
