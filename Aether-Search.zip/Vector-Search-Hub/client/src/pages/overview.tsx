import { motion } from "framer-motion";
import { ArrowRight, Database, Search, Zap, Cpu } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

export default function Overview() {
  return (
    <div className="space-y-12 pb-10">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl border border-border/50 bg-card/50">
        <div className="absolute inset-0 z-0 opacity-40">
           <div className="absolute inset-0 bg-gradient-to-r from-background via-transparent to-background/20" />
           <img 
             src="/hero-network.png" 
             alt="Neural Network" 
             className="w-full h-full object-cover mix-blend-overlay"
           />
        </div>
        
        <div className="relative z-10 p-8 md:p-16 max-w-3xl space-y-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-mono mb-4">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              Aether Search Engine
            </div>
            <h1 className="text-4xl md:text-6xl font-display font-bold leading-tight tracking-tight">
              Aether: Powered by <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400 glow-text">
                Endee Vector DB
              </span>
            </h1>
          </motion.div>
          
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-xl"
          >
            Aether is a high-performance demonstration of Endee, an embedded vector database designed for Semantic Search, RAG, and AI-driven recommendations.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
            className="flex flex-wrap gap-4 pt-4"
          >
            <Link href="/search">
              <Button size="lg" className="h-12 px-8 text-base shadow-lg shadow-primary/20">
                Try Live Demo <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
            </Link>
            <Link href="/architecture">
              <Button size="lg" variant="outline" className="h-12 px-8 text-base bg-background/50 backdrop-blur">
                View Architecture
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="grid md:grid-cols-3 gap-6">
        <FeatureCard 
          icon={Search}
          title="Semantic Search"
          description="Go beyond keywords. Find documents based on meaning and context using advanced vector embeddings."
          delay={0.1}
        />
        <FeatureCard 
          icon={Cpu}
          title="RAG Workflows"
          description="Retrieval Augmented Generation made simple. Fetch relevant context to ground your LLM responses."
          delay={0.2}
        />
        <FeatureCard 
          icon={Zap}
          title="High Performance"
          description="Lightning fast similarity search optimized for embedded applications and edge deployment."
          delay={0.3}
        />
      </section>

      {/* Problem Statement */}
      <section className="grid md:grid-cols-2 gap-12 items-center p-8 rounded-2xl border border-border/50 bg-card/30">
        <div className="space-y-4">
          <h2 className="text-3xl font-display font-bold">The Challenge</h2>
          <p className="text-muted-foreground leading-relaxed">
            Traditional keyword search fails to capture user intent. In the age of AI, applications need to understand context, not just match strings.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Endee bridges this gap by providing a lightweight, efficient vector store that integrates seamlessly into your Node.js and Python workflows, enabling true semantic understanding without the overhead of massive infrastructure.
          </p>
        </div>
        <div className="relative h-64 bg-zinc-950 rounded-lg border border-border p-4 font-mono text-sm overflow-hidden flex flex-col justify-center">
             <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
             <div className="space-y-2 z-10 text-zinc-400">
               <div className="flex gap-4"><span className="text-zinc-600">01</span> <span>query = <span className="text-green-400">"space exploration"</span></span></div>
               <div className="flex gap-4"><span className="text-zinc-600">02</span> <span>vector = model.embed(query)</span></div>
               <div className="flex gap-4"><span className="text-zinc-600">03</span> <span>results = db.search(vector)</span></div>
               <div className="flex gap-4"><span className="text-zinc-600">04</span> <span>print(results)</span></div>
               <div className="mt-4 p-3 bg-zinc-900/80 rounded border border-zinc-800 text-blue-300">
                 {`> Found: "Voyager 1" (Score: 0.92)`}<br/>
                 {`> Found: "Mars Rover" (Score: 0.88)`}
               </div>
             </div>
        </div>
      </section>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, description, delay }: { icon: any, title: string, description: string, delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.5 }}
      viewport={{ once: true }}
    >
      <Card className="h-full bg-card/50 backdrop-blur border-border/50 hover:border-primary/50 transition-colors">
        <CardHeader>
          <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center text-primary mb-4">
            <Icon className="w-6 h-6" />
          </div>
          <CardTitle className="font-display text-xl">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-base">{description}</CardDescription>
        </CardContent>
      </Card>
    </motion.div>
  );
}
