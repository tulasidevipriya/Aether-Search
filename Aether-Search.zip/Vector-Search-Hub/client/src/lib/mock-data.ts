export interface Doc {
  id: string;
  title: string;
  content: string;
  category: "Space" | "AI" | "Physics" | "Biology";
  vector_id: string;
  score?: number;
}

export const mockDocuments: Doc[] = [
  {
    id: "doc_1",
    vector_id: "vec_892j2",
    title: "The Voyager Probes",
    category: "Space",
    content: "Voyager 1 and Voyager 2 were launched in 1977 to take advantage of a favorable alignment of the outer planets. They are the only spacecraft to enter interstellar space."
  },
  {
    id: "doc_2",
    vector_id: "vec_129s2",
    title: "Transformer Architecture",
    category: "AI",
    content: "The Transformer is a deep learning architecture introduced in 2017. It utilizes a self-attention mechanism, differentially weighting the significance of each part of the input data."
  },
  {
    id: "doc_3",
    vector_id: "vec_552k9",
    title: "Quantum Entanglement",
    category: "Physics",
    content: "Quantum entanglement is a physical phenomenon that occurs when a group of particles are generated, interact, or share spatial proximity in a way such that the quantum state of each particle cannot be described independently."
  },
  {
    id: "doc_4",
    vector_id: "vec_992m1",
    title: "CRISPR-Cas9",
    category: "Biology",
    content: "CRISPR-Cas9 is a unique technology that enables geneticists and medical researchers to edit parts of the genome by removing, adding or altering sections of the DNA sequence."
  },
  {
    id: "doc_5",
    vector_id: "vec_773p4",
    title: "Black Holes",
    category: "Space",
    content: "A black hole is a region of spacetime where gravity is so strong that nothing—no particles or even electromagnetic radiation such as light—can escape from it."
  },
  {
    id: "doc_6",
    vector_id: "vec_331x5",
    title: "Reinforcement Learning",
    category: "AI",
    content: "Reinforcement learning (RL) is an area of machine learning concerned with how intelligent agents ought to take actions in an environment in order to maximize the notion of cumulative reward."
  }
];

export async function searchVectors(query: string): Promise<Doc[]> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 600));
  
  // Simple keyword matching simulation for "semantic" search
  const lowerQuery = query.toLowerCase();
  
  return mockDocuments
    .map(doc => ({
      ...doc,
      score: (doc.content.toLowerCase().includes(lowerQuery) || doc.title.toLowerCase().includes(lowerQuery)) 
        ? 0.9 + Math.random() * 0.09 
        : 0.6 + Math.random() * 0.2
    }))
    .sort((a, b) => (b.score || 0) - (a.score || 0))
    .slice(0, 3);
}

export async function generateRAGResponse(query: string, context: Doc[]): Promise<string> {
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (context.length === 0 || context[0].score! < 0.7) {
    return "I don't have enough specific information in the vector database to answer that accurately.";
  }

  // Mock responses based on the most relevant document
  const topDoc = context[0];
  
  if (topDoc.category === "Space") {
    return `Based on the retrieved context about ${topDoc.title}, I can explain that ${topDoc.content.toLowerCase()} This demonstrates the capability of the Endee vector store to retrieve precise scientific data.`;
  }
  if (topDoc.category === "AI") {
    return `The vector search retrieved key information regarding ${topDoc.title}. Specifically, ${topDoc.content} This is crucial for modern NLP applications.`;
  }
  
  return `According to the knowledge base (Source: ${topDoc.title}), ${topDoc.content}`;
}
