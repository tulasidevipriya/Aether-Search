import { Link, useLocation } from "wouter";
import { 
  Sidebar, 
  SidebarContent, 
  SidebarHeader, 
  SidebarMenu, 
  SidebarMenuItem, 
  SidebarMenuButton,
  SidebarProvider,
  SidebarTrigger,
  SidebarFooter
} from "@/components/ui/sidebar";
import { 
  LayoutDashboard, 
  Search, 
  Network, 
  BookOpen, 
  Github,
  Database
} from "lucide-react";
import { Separator } from "@/components/ui/separator";

const navigation = [
  { name: "Overview", href: "/", icon: LayoutDashboard },
  { name: "Search Demo", href: "/search", icon: Search },
  { name: "Architecture", href: "/architecture", icon: Network },
  { name: "Setup Guide", href: "/setup", icon: BookOpen },
];

export function AppLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background text-foreground">
        <AppSidebar location={location} />
        <main className="flex-1 flex flex-col min-h-screen transition-all duration-300 ease-in-out">
          <div className="sticky top-0 z-20 flex items-center h-16 px-6 gap-4 border-b bg-background/80 backdrop-blur-md">
            <SidebarTrigger />
            <div className="flex-1 font-mono text-sm opacity-50">
              Aether Search / {navigation.find(n => n.href === location)?.name || "Dashboard"}
            </div>
            <a href="https://github.com/EndeeLabs/endee" target="_blank" rel="noopener noreferrer" 
               className="flex items-center gap-2 text-sm font-medium hover:text-primary transition-colors">
              <Github className="w-4 h-4" />
              <span className="hidden sm:inline">Endee Labs</span>
            </a>
          </div>
          <div className="flex-1 p-6 md:p-8 overflow-x-hidden">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

function AppSidebar({ location }: { location: string }) {
  return (
    <Sidebar className="border-r border-border/50">
      <SidebarHeader className="h-16 flex items-center px-6 border-b border-border/50">
        <div className="flex items-center gap-2 font-display font-bold text-xl tracking-tight">
          <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground">
            <Database className="w-5 h-5" />
          </div>
          <span>Aether</span>
        </div>
      </SidebarHeader>
      <SidebarContent className="px-3 py-4">
        <SidebarMenu>
          {navigation.map((item) => (
            <SidebarMenuItem key={item.href}>
              <Link href={item.href}>
                <SidebarMenuButton 
                  isActive={location === item.href}
                  className="w-full justify-start gap-3 h-10 transition-all duration-200"
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.name}</span>
                </SidebarMenuButton>
              </Link>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="p-4 border-t border-border/50">
        <div className="text-xs text-muted-foreground">
          <p>Powered by Endee DB</p>
          <p className="mt-1">Aether Search v1.0.0</p>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
